import React from 'react';
import Logo from '../../assets/img/Logo.png';
import { FooterBase } from './styles';

function Footer() {
  return (
    <FooterBase>
      <a href="https://www.alura.com.br/">
        <img className="Logo" src={Logo} alt="AluraFlix logo" />
      </a>
      <p>
        {' '}
        <a href="https://www.alura.com.br/">
        
        </a>
      </p>
    </FooterBase>
  );
}

export default Footer;
