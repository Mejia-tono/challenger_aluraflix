import React from 'react';
import SlickSlider from 'react-slick';
import styled from 'styled-components';

const Container = styled.div`
  width: 100%;
  .slick-prev,
  .slick-next {
    z-index: 50;
    top: 50%;
    transform: translateY(-50%);
    width: 30px;
    height: 30px;
    background-color: rgba(0, 0, 0, 0.5);
    border-radius: 50%;
    border: none;
    cursor: pointer;
    position: absolute;
  }
  
  .slick-prev {
    left: 10px;
  }
  .slick-next {
    right: 10px;
  }
`;

export const SliderItem = styled.div`
  margin: 0 8px; /* Ajusta el margen entre los elementos */
  width: 298px; /* Ancho fijo de cada elemento */
  img {
    width: 100%;
    height: auto;
    border-radius: 8px;
  }
`;

const Slider = ({ children }) => (
  <Container>
    <SlickSlider
      dots={false}
      infinite={false}
      speed={300}
      slidesToShow={4} // Ajusta la cantidad de elementos a mostrar
      slidesToScroll={1} // Ajusta la cantidad de elementos a desplazar
      responsive={[
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
          },
        },
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 2,
          },
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
          },
        },
      ]}
    >
      {children}
    </SlickSlider>
  </Container>
);

export default Slider;
