import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import RegistroCategoria from './pages/registro/Categoria';
import RegistroVideo from './pages/registro/Video';

// Página 404 para mostrar en caso de ruta no encontrada
const Pagina404 = () => (
  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}>
    <h1>¡Ops, algo se rompió!</h1>
  </div>
);

ReactDOM.render(
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/registro/video" element={<RegistroVideo />} />
      <Route path="/registro/categoria" element={<RegistroCategoria />} />
      <Route path="*" element={<Pagina404 />} />
    </Routes>
  </BrowserRouter>,
  document.getElementById('root')
);
