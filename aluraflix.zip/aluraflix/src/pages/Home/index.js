import React from 'react';
import BannerMain from '../../components/BannerMain';
import Carrusel from '../../components/Carrusel';
import Footer from '../../components/Footer';
import Menu from '../../components/Menu';
import datosIniciales from '../../data/datos_iniciales.json';

function Home() {
  return (
    <div style={{ background: "#141414" }}>
      <Menu />

      <BannerMain
        videoTitle={datosIniciales.categorias[0].videos[0].titulo}
        url={datosIniciales.categorias[0].videos[0].url}
        videoDescription={"¿Qué es Front-end? Trabajando en el área, los términos HTML, CSS y JavaScript son parte de la rutina de los desarrolladores y desarrolladoras. Pero, ¿qué hacen exactamente? ¡Descúbrelo con Vanessa!"}
      />

      {datosIniciales.categorias.map((categoria, index) => (
        <Carrusel
          key={index}
          ignoreFirstVideo={index === 0} 
          category={categoria}
        />
      ))}

      <Footer />
    </div>
  );
}

export default Home;
