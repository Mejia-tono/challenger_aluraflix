import React from 'react';
import { Link } from 'react-router-dom';
import PageDefault from '../../../components/PageDefault';

function RegistroVideo() {
  return (
    <PageDefault>
      <h1>Registro de Video</h1>

      <Link to="/registro/categoria">
        Registrar Categoria
      </Link>
    </PageDefault>
  )
}

export default RegistroVideo;