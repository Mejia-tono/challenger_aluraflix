import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import FormField from '../../../components/FormField';
import PageDefault from '../../../components/PageDefault';

function RegistroCategoria() {
  const valoresIniciales = {
    nombre: '',
    descripción: '',
    color: '',
  };
  const [categorías, setCategorías] = useState([]);
  const [values, setValues] = useState(valoresIniciales);

  function setValue(clave, valor) {
    // clave: nombre, descripción, bla, bli
    setValues({
      ...values,
      [clave]: valor, // nombre: 'valor'
    });
  }

  function handleChange(infosDelEvento) {
    setValue(
      infosDelEvento.target.getAttribute('name'),
      infosDelEvento.target.value,
    );
  }

  // ============

  useEffect(() => {
    if (window.location.href.includes('localhost')) {
      const URL = 'http://localhost:3000/categorias';
      fetch(URL)
        .then(async (respuestaDelServidor) => {
          if (respuestaDelServidor.ok) {
            const respuesta = await respuestaDelServidor.json();
            setCategorías(respuesta);
            return;
          }
          throw new Error('No fue posible obtener los datos');
        });
    }
  }, []);

  return (
    <PageDefault>
      <h1>
        Registro de Categoría:
        {values.nombre}
      </h1>

      <form onSubmit={function handleSubmit(infosDelEvento) {
        infosDelEvento.preventDefault();

        setCategorías([
          ...categorías,
          values,
        ]);

        setValues(valoresIniciales);
      }}
      >

        <FormField
          label="Nombre de la Categoría"
          type="text"
          name="nombre"
          value={values.nombre}
          onChange={handleChange}
        />

        <FormField
          label="Descripción:"
          type="text"
          name="descripción"
          value={values.descripción}
          onChange={handleChange}
        />
      

        <FormField
          label="Color"
          type="color"
          name="color"
          value={values.color}
          onChange={handleChange}
        />
       

        <button type="submit">
          Registrar
        </button>
      </form>

      <ul>
        {categorías.map((categoría) => (
          <li key={`${categoría.id}`}>
            {categoría.título}
          </li>
        ))}
      </ul>

      <Link to="/">
        Ir a inicio
      </Link>
    </PageDefault>
  );
}

export default RegistroCategoria;
